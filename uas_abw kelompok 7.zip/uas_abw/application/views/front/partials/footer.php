<footer class="section p-3 bg-dark text-white">
    <div class="text-center">&copy; Copyright <?php echo date("Y"); ?> </div>
</footer>
</body>

</html>